package com.alura.foro.model;

public enum Estado {
    ACTIVO,
    INACTIVO
}
