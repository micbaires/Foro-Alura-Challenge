package com.alura.foro.dto.topico;

public record DatosActualizarTopico(
        String titulo,
        String mensaje
) {
}
